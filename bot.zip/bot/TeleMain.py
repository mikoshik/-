import telebot
import logging

# Замените 'YOUR_BOT_TOKEN' на ваш токен бота
API_TOKEN = '6890240044:AAGdUrvE2Bao8nH4MyJV3o8-u-6fQtoI5eY'

# Настройка логирования
logging.basicConfig(level=logging.INFO)

# Создание бота
bot = telebot.TeleBot(API_TOKEN)

# Главное меню
main_menu_markup = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
main_menu_markup.row(telebot.types.KeyboardButton("Услуги и цены"))
main_menu_markup.row(telebot.types.KeyboardButton("Акции и скидки"))
main_menu_markup.row(telebot.types.KeyboardButton("О клинике"))
main_menu_markup.row(telebot.types.KeyboardButton("Контакты"))

# Обработчик команды /start
@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Добрый день! Рад приветствовать вас в Международной клинике 'МАК'. Чем могу помочь?", reply_markup=main_menu_markup)

# Обработчики кнопок главного меню
@bot.message_handler(func=lambda message: message.text == "Услуги и цены")
def services_and_prices(message):
    bot.send_message(message.chat.id, """
    **Наши услуги:**

    - Кардиология
    - Неврология
    - Терапия
    - Хирургия
    - Педиатрия
    - Стоматология
    
    """, parse_mode="Markdown" )

@bot.message_handler(func=lambda message: message.text == "Акции и скидки")
def promotions(message):
    bot.send_message(message.chat.id, """
    **Акции и скидки:**

    * Скидка 20% на все виды массажа в мае!
    * Бесплатная консультация гинеколога для новых пациентов!
    
    """, parse_mode="Markdown" )

@bot.message_handler(func=lambda message: message.text == "О клинике")
def about_clinic(message):
    bot.send_message(message.chat.id, """
    **Международная клиника "МАК"** - 
    это современный медицинский центр, предоставляющий широкий спектр услуг по диагностике и лечению заболеваний. Мы работаем с 2000 года и за это время помогли тысячам пациентов.
    """, parse_mode="Markdown" )

@bot.message_handler(func=lambda message: message.text == "Контакты")
def contacts(message):
    bot.send_message(message.chat.id, """
    **Наши контакты:**

    - Адрес: г. Москва, ул. Примерная, д. 1
    - Телефон: +7 (495) 123-45-67
    - Email: info@mak-med.ru 
    """, parse_mode="Markdown" )

# Запуск бота
bot.polling()
