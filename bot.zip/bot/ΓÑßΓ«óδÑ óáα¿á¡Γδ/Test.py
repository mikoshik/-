import asyncio
import logging
from aiogram import Bot, Dispatcher, types


# Замените 'YOUR_BOT_TOKEN' на ваш токен бота
API_TOKEN = '6461342510:AAGBiI74zRYuavkdNLsQdBCCpTc2wwDr8Ck'

# Настройка логирования
logging.basicConfig(level=logging.INFO)

# Инициализация бота и диспетчера
bot = Bot(token=API_TOKEN)
dp = Dispatcher()

# Главное меню
main_menu_keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
main_menu_buttons = ["Услуги и цены", "Акции и скидки", "О клинике", "Контакты"]
main_menu_keyboard.add(*main_menu_buttons)

# Обработчик команды /start
@dp.message_handler(commands=['start'])
async def cmd_start(message: types.Message):
    await message.answer("Добрый день! Рад приветствовать вас в Международной клинике 'МАК'. Чем могу помочь?", reply_markup=main_menu_keyboard)

# Обработчики кнопок главного меню
@dp.message_handler(lambda message: message.text == "Услуги и цены")
async def services_and_prices(message: types.Message):
    await message.answer("""
    **Наши услуги:**

    * Кардиология
    * Неврология
    * Терапия
    * Хирургия
    * Педиатрия
    * Стоматология

    **Цены:**

    * Консультация терапевта: от 1500 рублей
    * ЭКГ: от 800 рублей
    * ... (добавьте остальные цены)
    """)

@dp.message_handler(lambda message: message.text == "Акции и скидки")
async def promotions(message: types.Message):
    await message.answer("""
    **Акции и скидки:**

    * Скидка 20% на все виды массажа в мае!
    * Бесплатная консультация гинеколога для новых пациентов!
    * ... (добавьте остальные акции)
    """)

@dp.message_handler(lambda message: message.text == "О клинике")
async def about_clinic(message: types.Message):
    await message.answer("""
    **Международная клиника "МАК"** - это современный медицинский центр, предоставляющий широкий спектр услуг по диагностике и лечению заболеваний. Мы работаем с 2000 года и за это время помогли тысячам пациентов.
    """)

@dp.message_handler(lambda message: message.text == "Контакты")
async def contacts(message: types.Message):
    await message.answer("""
    **Наши контакты:**

    * Адрес: г. Москва, ул. Примерная, д. 1
    * Телефон: +7 (495) 123-45-67
    * Email: info@mak-med.ru
    """)

# Запуск бота
async def main():
    await dp.start_polling(bot)

if __name__ == '__main__':
    asyncio.run(main())
